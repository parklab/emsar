

char getb(char*, int);
void putb(char*, int, char);
int bitsize(int);

